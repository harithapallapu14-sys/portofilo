# Haritha Pallapu — Portfolio Website

A responsive, animated personal portfolio built with plain HTML, CSS and JavaScript (no frameworks).

## Folder structure

```
portfolio/
├── index.html          Main page (all sections)
├── css/
│   └── style.css       All styling, animations, responsive rules
├── js/
│   └── script.js       Nav, scroll reveal, skill bars, hero typing effect, form
├── assets/
│   └── PLACE_RESUME_HERE.txt   Put Haritha_Pallapu_Resume.pdf here
└── README.md
```

See the chat response for full instructions on customizing, testing locally, and deploying.
